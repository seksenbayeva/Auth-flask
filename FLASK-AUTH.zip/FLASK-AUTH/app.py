from flask import Flask, render_template, request, redirect, url_for, session, flash
import json
import os
import jwt  
import datetime

app = Flask(__name__)
app.secret_key = 'your-secret-key'

# Путь к файлу JSON для хранения данных пользователей
users_file_path = 'users.json'

def load_users():
    if os.path.exists(users_file_path):
        with open(users_file_path, 'r') as file:
            try:
                return json.load(file)
            except json.JSONDecodeError:
                return {}
    return {}

def save_users(users):
    with open(users_file_path, 'w') as file:
        json.dump(users, file)

# Функция для создания токена
def create_token(username):
    payload = {'username': username}
    return jwt.encode(payload, app.secret_key, algorithm='HS256')

# Декоратор, проверяющий наличие токена
def token_required(f):
    def decorated(*args, **kwargs):
        token = request.args.get('token')  # Получаем токен из запроса
        if not token:
            return redirect(url_for('login'))  # Если токен отсутствует, перенаправляем на страницу входа
        try:
            jwt.decode(token, app.secret_key, algorithms=['HS256'])  # Проверяем токен
        except jwt.ExpiredSignatureError:
            return redirect(url_for('login'))  # Если токен истек, перенаправляем на страницу входа
        return f(*args, **kwargs)
    return decorated

def refresh_token():
    if 'token' in session:
        try:
            # Декодируем токен
            decoded_token = jwt.decode(session['token'], app.secret_key, algorithms=['HS256'])
            # Если токен истек, генерируем новый и обновляем в сессии
            if decoded_token['exp'] < datetime.utcnow():
                username = decoded_token['username']
                new_token = create_token(username)  # Создаем новый токен
                session['token'] = new_token  # Обновляем токен в сессии
        except jwt.ExpiredSignatureError:
            # Если возникает ошибка истечения срока действия токена, генерируем новый
            username = decoded_token['username']
            new_token = create_token(username)  # Создаем новый токен
            session['token'] = new_token  # Обновляем токен в сессии

@app.route('/')
def home():
    if 'username' in session:
        return render_template('home.html', username=session['username'])
    else: 
        return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    users = load_users()
    if request.method == 'POST':
        username = request.form['username']
        pwd = request.form['password']
        
        if username in users and users[username]['password'] == pwd:
            token = create_token(username)  # Создаем токен
            session['username'] = username
            flash('Вы успешно вошли!', 'success')  # Уведомление об успешной аутентификации
            return redirect(url_for('home'))
        else:
            flash('Неверное имя пользователя или пароль', 'error')  # Уведомление об ошибке аутентификации
            return render_template('login.html', error='Invalid username or password')
        
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    users = load_users()
    if request.method == 'POST':
        username = request.form['username']
        pwd = request.form['password']
        
        if username not in users:  # Проверяем, есть ли уже пользователь с таким именем
            users[username] = {'password': pwd}
            save_users(users)
            return redirect(url_for('login'))
        else:
            flash('Username already exists', 'error')  # Уведомляем об ошибке существующего имени пользователя
            return render_template('register.html')
    
    # Очищаем сообщения Flash при загрузке страницы регистрации перед отправкой нового запроса
    # Устанавливаем пустой список сообщений Flash
    if '_flashes' in session:
        session['_flashes'] = []
    
    return render_template('register.html')

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

@app.route('/protected')
@token_required
def protected():
    return "You're in a protected area!"

if __name__ =='__main__':
    app.run(debug=True)


